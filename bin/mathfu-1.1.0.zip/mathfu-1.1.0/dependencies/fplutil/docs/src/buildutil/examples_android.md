Android Buildutil Example    {#buildutil_examples_android_code}
=========================

@include android/build.py
